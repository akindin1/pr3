﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PZ6_1
{
    class DemonEnemy
    {
        private int intelligence1;
        private int DemonHP1;
        private int DemonPower1;
        public int Intelekt
        {
            get
            {
                return intelligence1;
            }
            set
            {
                if (value < 101 && value > 0)
                {
                    intelligence1 = value;
                }

                else
                {
                    Console.WriteLine("Разум меньше минимального, или больше максимального - присвоенно стандартное значение: 50 ");
                }
            }
        }

                public int DemonHP
        {
            get
            {
                return DemonHP1;

            }
            set
            {
                if (value < 101 && value > 0)
                {
                    DemonHP1 = value;
                }
                else
                {
                    Console.WriteLine("ХП меньше минимального, или больше максимального - присвоенно стандартное значение: 100 ");

                }
            }
        }

        public int DemonPower
        {
            get
            {
                return DemonPower1;

            }
            set
            {
                if (value < 101 && value > 0)
                {
                    DemonPower1 = value;
                }
                else
                {
                    Console.WriteLine("Сила меньше минимального, или больше максимального - присвоенно стандартное значение: 50 ");
                }
            }
        }
    }
}
