﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PZ6_1
{
    class Monster
    {
        public int _HP;
        public int _Power;

        public Monster()
        {
        }



        public int MonsterHP
        {
            get
            {
                return _HP;

            }
            set
            {
                if (value < 101 && value > 0)
                {
                    _HP = value;
                }
                else
                {
                    Console.WriteLine("ХП меньше минимального, или больше максимального - присвоенно стандартное значение: 100 ");

                }
            }
        }

        public int MonsterPower
        {
            get
            {
                return _Power;

            }
            set
            {
                if (value < 101 && value > 0)
                {
                    _Power = value;
                }
                else
                {
                    Console.WriteLine("Сила меньше минимального, или больше максимального - присвоенно стандартное значение: 50 ");
                }
            }
        }
    }
}
