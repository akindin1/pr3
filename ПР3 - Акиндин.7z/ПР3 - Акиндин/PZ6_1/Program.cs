﻿using System;

namespace PZ6_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("|| Характеристики Монстра:");
            Console.WriteLine("|| Введите ХП монстра");
            Console.WriteLine("|| Введите Силу монстра");
            Console.WriteLine("||______________________");
            Console.WriteLine(" ");

            Monster monster = new Monster();
            monster.MonsterHP = Convert.ToInt32(Console.ReadLine());
            monster.MonsterPower = Convert.ToInt32(Console.ReadLine());

            int sum = monster._HP + monster._Power;
            int basicHP = 100;
            int basicPower = 50;


            if (sum < 150 && sum > 2)
            {

                Console.WriteLine("HP: {0} ", monster._HP);
                Console.WriteLine("Power: {0}", monster._Power);

            }
            else
            {
                Console.WriteLine("HP меньше минимального, или больше максимального - присвоенно стандартное значение: {0} ", basicHP);
                Console.WriteLine("Power меньше минимального, или больше максимального - присвоенно стандартное значение: {0}", basicPower);
            }

            Console.WriteLine(" ");
            Console.WriteLine("|| Характеристики Монстра:");
            Console.WriteLine("|| Введите ХП демона");
            Console.WriteLine("|| Введите Силу демона");
            Console.WriteLine("|| Введите Разум демона");
            Console.WriteLine("||_____________________");
            Console.WriteLine(" ");
            
           

            DemonEnemy demon = new DemonEnemy();
            demon.DemonHP = Convert.ToInt32(Console.ReadLine());
            demon.DemonPower = Convert.ToInt32(Console.ReadLine());
            int basicintelligence2 = 50;
            demon.Intelekt = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(" ");

            int suma = demon.DemonHP + demon.DemonPower + demon.Intelekt;

            if (suma < 200 && suma > 0)
            {

                    Console.WriteLine("HP: {0} ", monster._HP);
                    Console.WriteLine("Power: {0}", monster._Power);
                    Console.WriteLine("Razum: {0}", demon.Intelekt);

                
            }
            else
            {
                Console.WriteLine("HP меньше минимального, или больше максимального - присвоенно стандартное значение: {0} ", basicHP);
                Console.WriteLine("Power меньше минимального, или больше максимального - присвоенно стандартное значение: {0}", basicPower);
                Console.WriteLine("Razum меньше минимального, или больше максимального - присвоенно стандартное значение: {0} ", basicintelligence2);
            }


            
        }
    }
    }
